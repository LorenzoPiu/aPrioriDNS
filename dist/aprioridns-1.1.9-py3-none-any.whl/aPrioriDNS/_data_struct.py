#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri May 10 20:07:56 2024

@author: lorenzo piu
"""

folder_structure = {
                     "data_path" : "data",
                     "grid_path" : "grid",
                     "chem_path" : "chem_thermo_tran"
                 }