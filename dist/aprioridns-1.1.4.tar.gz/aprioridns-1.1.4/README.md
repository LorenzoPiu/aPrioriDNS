# Tutorial dataset

This folder contains a dataset to use to test the library. The dataset was extracted from [this](https://blastnet.github.io/jung2021.html) DNS simulation. 

The domain was reduced to a size of 200x200x100 grid points, without changing the formatting.

<p align="center">
  <img src="https://github.com/LorenzoPiu/Images/blob/main/Subdomain2.png" width="40%">
</p>
